package com.test.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.test.entity.User;
import com.test.util.DBUtil;

public class UserService {
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private DBUtil dbutil = null;
	
	public UserService(){
		dbutil = new DBUtil();
		this.conn = dbutil.getConnection();
	}
	
	public boolean findLogin(User user){
		boolean flag = false;
		String sql = "select username from user where username = ?and password =?";
		try {
			this.pstmt = this.conn.prepareStatement(sql);
			this.pstmt.setString(1, user.getUsername());
			this.pstmt.setString(2, user.getPassword());
			ResultSet result = this.pstmt.executeQuery();
			if(result.next()){
				flag = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			dbutil.DBCclose();
		}
		
		return flag;
	}
	
	public boolean registerLogin(User user){
		boolean flag = false;
		String sql = "insert into user(username,password) values (?,?)";
		try {
			this.pstmt = this.conn.prepareStatement(sql);
			this.pstmt.setString(1, user.getUsername());
			this.pstmt.setString(2, user.getPassword());
			if(this.pstmt.executeUpdate()==1){
				flag = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			dbutil.DBCclose();
		}
		return flag;
	}
	

}
