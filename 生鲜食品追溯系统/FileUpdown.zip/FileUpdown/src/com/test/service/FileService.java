package com.test.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.test.entity.FileInfo;
import com.test.util.DBUtil;

public class FileService {
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private DBUtil dbutil= null;
	
	public FileService(){
		dbutil = new DBUtil();
		this.conn = dbutil.getConnection();
		
	}
	
	public boolean uploadFile(FileInfo fileInfo){
		boolean flag = false;
		String sql = "insert into fileinfo(filename,content) values (?,?)";
		try {
			this.pstmt = this.conn.prepareStatement(sql);
			this.pstmt.setString(1,fileInfo.getFilename() );
			this.pstmt.setBytes(2, fileInfo.getContent());
			if(this.pstmt.executeUpdate()==1){
				flag = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			dbutil.DBCclose();
		}
		return flag;
	}

}
