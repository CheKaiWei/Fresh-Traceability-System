package com.test.entity;

import java.io.Serializable;

public class FileInfo implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private int id;//�ļ����
	private String filename;//�ļ���
	private byte[] content;//�ļ�����
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public byte[] getContent() {
		return content;
	}
	public void setContent(byte[] content) {
		this.content = content;
	}
	public FileInfo(String filename, byte[] content) {
		this.filename = filename;
		this.content = content;
	}
	
	

}
